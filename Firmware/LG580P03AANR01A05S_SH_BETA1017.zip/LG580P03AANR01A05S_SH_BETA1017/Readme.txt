Version: LG580P03AANR01A05S_SH_BETA1017

Default Configuration:
(1) The default satellite constellation configuration is GPS L1/L2/L5 + Galileo E1/E5a/E5b + BDS B1I/B1C/B2a/B2b/B2I + QZSS L1/L2/L5 + NavIC L5.
(2) The default UART baud rate is 460800 bps.

Change Point：
(1)Changed the default value of the <MaskLow> field in the $PQTMCFGSAT command for Galileo E1, E5a, E5b, and E6 bands to 0x77D4DFFE.
(2)Added $PQTMENV message to output environment information.
(3)Added $PQTMCLRMSG command to clear the messages output by the communication port.
(4)Added $PQTMLSTMSG command to list the messages output by the communication port.
(5)Added $PQTMRTCMIS message to output the RTCM injection status.
(6)Added $PQTMCFGRTKRL command to configure RTK reliability level.
(7)Added $PQTMCFGNAVMODE command to configure the navigation mode.
(8)Fixed the issue of UTC time being lost after sending a hot/warm start command.
(9)Improved the RTK fix rate, fix accuracy, and float accuracy in some weak signal scenarios.
(10)Optimized long baseline dynamic performance.
(11)Improved static velocity accuracy.
(12)Changed the altitude limit to 18000 m and the speed limit to 515 m/s.
(13)Added RTKHOLD feature.
(14)Added <PL_TIME> field to $PQTMPL message.
(15)Fixed the issue of incorrect return format for the $PQTMCFGRTKSRCTYPE and $PQTMSN commands.

Description related to $PQTMCFGNAVMODE command.
Type:Set/Get
Synopsis:
     //Set
     $PQTMCFGNAVMODE,W,<Mode>*<Checksum><CR><LF>
     //Get
     $PQTMCFGNAVMODE,R*<Checksum><CR><LF>
Parameter:
     <Mode>：Navigation mode.
            0 = Normal mode. This mode is a basic mode. It is applied to most of scenarios. (for example, driving scenario).
            1~4 = Reserved.
            5 = Dynamic flight mode. Used for Dynamic flight mode with equivalent dynamics range and vertical acceleration on different flight phase(Default).
            6~10 = Reserved.
            11 = Mower mode. For mower application .
            12~13 = Reserved.
            14 = Agriculture mode. For agriculture application.
Result:
     If successful, the module returns:
     //Response to Set command:
     $PQTMCFGNAVMODE,OK*<Checksum><CR><LF>
     //Response to Get command:
     $PQTMCFGNAVMODE,OK,<Mode>*<Checksum><CR><LF>
     If failed, the module returns:
     $PQTMCFGNAVMODE,ERROR,<ErrCode>*<Checksum><CR><LF>
Example:
     //Set
     $PQTMCFGNAVMODE,W,11*57
     $PQTMNAVMODE,OK*6A
     //Get
     $PQTMCFGNAVMODE,R*7E
     $PQTMNAVMODE,OK,11*46

版本：LG580P03AANR01A05S_SH_BETA1017

默认配置：
（1）默认星系配置：GPS L1/L2/L5 + Galileo E1/E5a/E5b + BDS B1I/B1C/B2a/B2b/B2I + QZSS L1/L2/L5 + NavIC L5。
（2）默认UART接口波特率：460800 bps。

修改点：
（1）修改了$PQTMCFGSAT指令中Galileo E1, E5a, E5b, E6频段<MaskLow>字段默认值为0x77D4DFFE。
（2）新增$PQTMENV语句，用于输出环境信息。
（3）新增$PQTMCLRMSG指令，用于清除通信端口输出的语句。
（4）新增$PQTMLSTMSG指令，用于列举通信端口输出的语句。
（5）新增$PQTMRTCMIS语句，用于输出RTCM注入状态。
（6）新增$PQTMCFGRTKRL指令，用于配置RTK可靠性等级。
（7）新增$PQTMCFGNAVMODE指令，用于配置导航模式。
（8）修复了发送热/温启动指令之后，UTC时间丢失的问题。
（9）提高了部分弱信号场景的RTK固定率、固定解精度和浮点解精度。
（10）优化了长基线动态性能。
（11）提高了静态速度精度。
（12）修改了高度极限值为18000 m，速度极限值为515 m/s。
（13）新增RTKHOLD功能。
（14）$PQTMPL语句新增<PL_TIME>字段。
（15）修复了$PQTMCFGRTKSRCTYPE和$PQTMSN指令返回格式错误的问题。

$PQTMCFGNAVMODE指令相关信息
类型：指令
格式：
     //设置
     $PQTMCFGNAVMODE,W,<Mode>*<Checksum><CR><LF>
     //查询
     $PQTMCFGNAVMODE,R*<Checksum><CR><LF>
参数：
     <Mode>：导航模式
            0 = 正常模式。此模式为基础模式，适用于大多数场景（例如驾驶场景）。
            1~4 = 保留
            5 = 飞行动态模式。用于不同飞行阶段具有相同动态范围和垂直加速度的飞行动态模式（默认）。
            6~10 = 保留
            11 = 割草机模式。适用于割草机场景。
            12~13 = 保留
            14 = 农机模式。适用于农机场景。    
结果：
     如果成功，模块返回：
     //设置命令响应：
     $PQTMCFGNAVMODE,OK*<Checksum><CR><LF>
     //查询命令响应：
     $PQTMCFGNAVMODE,OK,<Mode>*<Checksum><CR><LF>
     如果失败，模块返回：
     $PQTMCFGNAVMODE,ERROR,<ErrCode>*<Checksum><CR><LF>
示例：
     //设置：
     $PQTMCFGNAVMODE,W,11*57
     $PQTMNAVMODE,OK*6A
     //查询：
     $PQTMCFGNAVMODE,R*7E
     $PQTMNAVMODE,OK,11*46


